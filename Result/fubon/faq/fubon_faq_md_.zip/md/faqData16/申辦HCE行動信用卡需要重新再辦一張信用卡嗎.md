# 申辦HCE行動信用卡需要重新再辦一張信用卡嗎？

使用本服務不需要重新申辦卡片或填寫信用卡申請書，只要您目前持有本行任一張已開卡之MasterCard/VISA信用卡即可於「台灣行動支付」APP內線上完成下載並即刻使用；如您尚未持有本行任一張MasterCard/VISA信用卡，請先完成信用卡申辦。  
[立即前往「線上辦卡」](https://ebank.taipeifubon.com.tw/EXT/common/CAC/Index.faces)
